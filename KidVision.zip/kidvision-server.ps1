# KidVision Local Server
# This script starts a tiny HTTP server so Edge can run JavaScript.
# Do NOT close this window while students are using KidVision.

$port = 8765
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path "$dir\kidvision.html")) {
    Write-Host "ERROR: kidvision.html not found in $dir" -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit 1
}

try {
    $listener = [System.Net.HttpListener]::new()
    $listener.Prefixes.Add("http://localhost:$port/")
    $listener.Start()
    Write-Host "KidVision server running on http://localhost:$port/" -ForegroundColor Green
    Write-Host "Do not close this window." -ForegroundColor Yellow
    
    while ($true) {
        $ctx = $listener.GetContext()
        $path = $ctx.Request.Url.LocalPath.TrimStart('/')
        if (-not $path) { $path = 'kidvision.html' }
        $file = Join-Path $dir $path
        
        if (Test-Path $file) {
            $bytes = [System.IO.File]::ReadAllBytes($file)
            $ext = [System.IO.Path]::GetExtension($file).ToLower()
            $mime = switch ($ext) {
                '.html' { 'text/html; charset=utf-8' }
                '.css'  { 'text/css' }
                '.js'   { 'application/javascript' }
                '.png'  { 'image/png' }
                '.jpg'  { 'image/jpeg' }
                '.svg'  { 'image/svg+xml' }
                '.ico'  { 'image/x-icon' }
                default { 'application/octet-stream' }
            }
            $ctx.Response.ContentType = $mime
            $ctx.Response.ContentLength64 = $bytes.Length
            $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $ctx.Response.StatusCode = 404
        }
        $ctx.Response.Close()
    }
} catch {
    Write-Host "Server error: $_" -ForegroundColor Red
    Read-Host "Press Enter to close"
} finally {
    if ($listener) { $listener.Stop() }
}
